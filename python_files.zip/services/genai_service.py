import google.generativeai as genai

# Configure the Gemini API (replace with your actual API key)
genai.configure(api_key="AIzaSyDCrj8dAHhgangbJsKwXcsvxti8yZs2K2CxmhM8")  # Replace with your actual API key
model = genai.GenerativeModel("gemini-1.5-flash")




