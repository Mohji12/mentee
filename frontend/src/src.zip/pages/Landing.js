import React, { useState, useEffect } from 'react';
import PullToRefresh from 'react-simple-pull-to-refresh';
import { Link } from 'react-router-dom';
import '../assets/css/Landing.css';
import EfficiencyImage from '../assets/images/efficiency.png';
import PersonalizationImage from '../assets/images/personalization.png';
import LearningImage from '../assets/images/learning.png';

const LandingPage = () => {
  // Refresh Function
  const handleRefresh = async () => {
    await new Promise((resolve) => setTimeout(resolve, 2000)); // Simulate API call
    window.location.href = window.location.href; // Force full page refresh
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="lp-landing-page">
        <Link to="/">
          <div className="lp-logo-left"></div>
        </Link>
        <div className="lp-logo-right"></div>
        <div className="lp-content">
          <div className="lp-image-section"></div>
          <div className="lp-text-section">
            <h1 className="lp-heading">Empower. Engage.<br />Excel.</h1>
            <p className="lp-paragraph lp-paragraph-primary">
              Revolutionizing mentorship with advanced<br />
              progress tracking, intuitive scheduling,<br />
              and effortless communication.
            </p>
          </div>

          <div className="lp-login-buttons">
            <Link to="/student_signup">
              <button className="lp-login-button">Get Started</button>
            </Link>
          </div>

          <div className="lp-icon-section">
            <div className="lp-icon-item">
              <img src={EfficiencyImage} alt="Efficiency" className="lp-icon" />
              <p className="lp-icon-description">Efficiency <br />& Accuracy</p>
            </div>
            <div className="lp-icon-item">
              <img src={PersonalizationImage} alt="Personalization" className="lp-icon" />
              <p className="lp-icon-description">Personalization <br />& Growth</p>
            </div>
            <div className="lp-icon-item">
              <img src={LearningImage} alt="Enhanced Learning" className="lp-icon" />
              <p className="lp-icon-description">Enhanced Learning <br />Experience</p>
            </div>
          </div>
        </div>
        <footer className="lp-footer">
          Powered by <a href="https://linktr.ee/biogred" className="lp-footer-link">BIOGRED</a>
        </footer>
      </div>
    </PullToRefresh>
  );
};

export default LandingPage;