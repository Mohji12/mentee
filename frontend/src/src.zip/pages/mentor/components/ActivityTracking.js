import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import "../../../assets/css/ActivityTracking.css";
import { API_BASE_URL } from "../../../api";

const ActivityTracking = () => {
  const { mentor_id } = useParams();
  const [activities, setActivities] = useState([]);
  const [filteredActivities, setFilteredActivities] = useState([]);
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [formData, setFormData] = useState({
    remarks: "",
    completed_in: "",
    benefitted: "false",
    proof: "",
  });
  const [searchUSN, setSearchUSN] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [studentOptions, setStudentOptions] = useState([]); // Store USN-Name options

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/mentor/${mentor_id}/activities`);
        if (!response.ok) {
          throw new Error("Failed to fetch activities");
        }
        const data = await response.json();
        setActivities(data);
        setFilteredActivities(data);

        // Create USN-Name options for the dropdown
        const uniqueStudents = {};
        data.forEach(activity => {
          uniqueStudents[activity.student_usn] = activity.student_name;
        });
        setStudentOptions(Object.entries(uniqueStudents).map(([usn, name]) => ({
          value: usn,
          label: `${usn} - ${name}`,
        })));

      } catch (error) {
        console.error(error.message);
      }
    };
    fetchActivities();
  }, [mentor_id]);

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchUSN(value);

    if (value === "") {
      setFilteredActivities(activities);
    } else {
      const filtered = activities.filter((activity) =>
        `${activity.student_usn} - ${activity.student_name}`.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredActivities(filtered);
    }
  };


  const handleUpdateClick = (activity) => {
    setSelectedActivity(activity);
    setFormData({
      remarks: activity.remarks || "",
      completed_in: activity.completed_in || "",
      benefitted: activity.benefitted ? "true" : "false",
      proof: activity.proof || "",
    });
    setShowPopup(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "completed_in" && parseInt(value, 10) < 0) {
      return;
    }
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();

    const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;
    if (formData.proof && !urlRegex.test(formData.proof)) {
      alert("Please enter a valid URL for the proof field.");
      return;
    }

    if (!selectedActivity || !selectedActivity.activity_id) {
      alert("Activity ID is missing");
      return;
    }

    const updatedFormData = {
      ...formData,
      benefitted: formData.benefitted === "true",
      completed_in: formData.completed_in ? parseInt(formData.completed_in, 10) : null,
    };

    try {
      const response = await fetch(
        `${API_BASE_URL}/mentor/${mentor_id}/update_activity/${selectedActivity.activity_id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedFormData),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to update activity");
      }

      alert("Activity updated successfully!");
      setShowPopup(false);
      setFormData({ remarks: "", completed_in: "", benefitted: "false", proof: "" });

      const refreshedResponse = await fetch(`${API_BASE_URL}/mentor/${mentor_id}/activities`);
      const refreshedData = await refreshedResponse.json();
      setActivities(refreshedData);
      setFilteredActivities(refreshedData);

      // Update student options after refresh
      const uniqueStudents = {};
        refreshedData.forEach(activity => {
          uniqueStudents[activity.student_usn] = activity.student_name;
        });
        setStudentOptions(Object.entries(uniqueStudents).map(([usn, name]) => ({
          value: usn,
          label: `${usn} - ${name}`,
        })));


    } catch (error) {
      console.error("Error updating activity:", error.message);
    }
  };

  return (
    <div className="activity-tracking__container">
      <h2 className="activity-tracking__title">Activity Tracking</h2>

      {/* Dropdown for USN-Name search */}
      <div className="activity-tracking__search">
        <select
          value={searchUSN}
          onChange={handleSearchChange}
          className="activity-tracking__search-dropdown"
        >
          <option value="">Select USN - Name</option> {/* Default option */}
          {studentOptions.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
      <br />

      <table className="activity-tracking__table">
        <thead>
          <tr>
            <th>Activity ID</th>
            <th>USN</th>
            <th>Name</th>
            <th>Activity</th>
            <th>Term Type</th>
            <th>Deadline</th>
            <th>Remarks</th>
            <th>CmpDays</th>
            <th>Benefitted</th>
            <th>Proof</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredActivities.map((activity) => (
            <tr key={activity.activity_id}>
              <td>{activity.activity_id}</td>
              <td>{activity.student_usn}</td>
              <td>{activity.student_name}</td>
              <td>{activity.activities}</td>
              <td>{activity.duration_type}</td>
              <td>{new Date(activity.deadline).toLocaleDateString()}</td>
              <td>{activity.remarks || "N/A"}</td>
              <td>{activity.completed_in || "N/A"}</td>
              <td>{activity.benefitted ? "Yes" : "No"}</td>
              <td>
                {activity.proof ? (
                  <a
                    href={activity.proof}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="activity-tracking__open-button"
                  >
                    Open
                  </a>
                ) : (
                  "N/A"
                )}
              </td>
              <td>
                <button
                  className="activity-tracking__update-button"
                  onClick={() => handleUpdateClick(activity)}
                >
                  Update
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table><br/><br/><br/>

      {showPopup && (
        <div className="activity-tracking__popup">
          <form className="activity-tracking__form" onSubmit={handleUpdateSubmit}>
            <h3 className="activity-tracking__popup-title">Update Activity</h3>
            <label>
              Remarks:
              <textarea
                name="remarks"
                value={formData.remarks}
                onChange={handleInputChange}
                onInput={(e) => {
                e.target.style.height = "auto"; // Reset height
                e.target.style.height = `${e.target.scrollHeight}px`; // Adjust height based on content
                }}
                className="activity-tracking__textarea"
                style={{ minHeight: "40px", maxHeight: "200px", overflowY: "auto" }}
                />
            </label>
            <label>
              Completed In:
              <input
                type="number"
                name="completed_in"
                value={formData.completed_in}
                onChange={handleInputChange}
                className="activity-tracking__input"
              />
            </label>
            <label>
              Benefitted:
              <select
                name="benefitted"
                value={formData.benefitted}
                onChange={handleInputChange}
                className="activity-tracking__select"
              >
                <option value="true">Yes</option>
                <option value="false">No</option>
              </select>
            </label>
            <label>
              Proof (URL):
              <input
                type="url"
                name="proof"
                value={formData.proof}
                onChange={handleInputChange}
                className="activity-tracking__input"
              />
            </label>
            <button type="submit" className="activity-tracking__submit-button">Update</button>
            <button type="button" className="activity-tracking__cancel-button" onClick={() => setShowPopup(false)}>
              Cancel
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default ActivityTracking;