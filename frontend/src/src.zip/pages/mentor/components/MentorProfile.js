import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import '../../../assets/css/MentorProfile.css';
import { API_BASE_URL } from '../../../api';
import { FaSignOutAlt } from 'react-icons/fa';  // Importing icons from react-icons

const Profile = () => {
  const { mentor_id } = useParams();
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetch profile details
    fetch(`${API_BASE_URL}/mentor/profile/${mentor_id}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Profile not found');
        }
        return response.json();
      })
      .then((data) => {
        setProfile(data);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching profile:', error);
        setIsLoading(false);
      });
  }, [mentor_id]);

  return (
    <div className="mentor-profile__content">
      <h2 className="mentor-profile__title">Profile</h2>

      {isLoading ? (
        <div className="mentor-profile__loading">
          <p>Loading...</p>
        </div>
      ) : profile && profile.mentor_name ? (
        <div className="mentor-profile__details">
          <p><strong>ID:</strong> {mentor_id}</p>
          <p><strong>Name:</strong> {profile.mentor_name}</p>
          <p><strong>Department:</strong> {profile.mentor_department}</p>
          <p><strong>Phone Number:</strong> {profile.mentor_phoneno}</p>
          <button className="mentor-profile-sidebar-logout-button">
            <Link to={`/logout`} className="mentor-sidebar-sidebar-logout-link">
              <FaSignOutAlt />&nbsp;&nbsp;&nbsp;&nbsp;Logout
            </Link>
          </button>
        </div>
      ) : (
        <div className="mentor-profile__no-profile">
          <p>No profile found.</p>
        </div>
      )}
    </div>
  );
};

export default Profile;
