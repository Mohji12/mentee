import React from 'react';
import { Link, useParams } from 'react-router-dom';
import '../../../assets/css/MentorSidebar.css';
import { FaUser, FaClipboardList, FaChartLine, FaRegClock } from 'react-icons/fa';

const MentorSidebar = () => {
  const { mentor_id } = useParams(); // Fetch the mentor_id from the URL
  return (
    <div className="mentor-sidebar__container">
      <Link to={`/mentor/${mentor_id}/profile`}>
        <div className="mentor-sidebar-logo-left"></div>
      </Link>
      <ul className="mentor-sidebar__menu">
        {/* Assigned Students */}
        <li>
          <Link to={`/mentor/${mentor_id}/assigned_students`} className="mentor-sidebar__menu-item">
            <FaClipboardList />&nbsp;&nbsp;&nbsp;&nbsp;Assigned Students
          </Link>
        </li>

        {/* Activity Tracking */}
        <li>
          <Link to={`/mentor/${mentor_id}/activity_tracking`} className="mentor-sidebar__menu-item">
            <FaChartLine />&nbsp;&nbsp;&nbsp;&nbsp;Activity Tracking
          </Link>
        </li>

        {/* Meetings */}
        <li>
          <Link to={`/mentor/${mentor_id}/meetings`} className="mentor-sidebar__menu-item">
            <FaRegClock />&nbsp;&nbsp;&nbsp;&nbsp;Meetings
          </Link>
        </li>

        {/* Profile */}
        <li>
          <Link to={`/mentor/${mentor_id}/profile`} className="mentor-sidebar__menu-item">
            <FaUser />&nbsp;&nbsp;&nbsp;&nbsp;Profile
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default MentorSidebar;
