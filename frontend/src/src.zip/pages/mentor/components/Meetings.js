import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Select from "react-select";
import "../../../assets/css/Meetings.css";
import { API_BASE_URL } from "../../../api";

const Meetings = () => {
  const { mentor_id } = useParams();
  const [assignedStudents, setAssignedStudents] = useState([]);
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [meetingDate, setMeetingDate] = useState("");
  const [venue, setVenue] = useState("");
  const [meetings, setMeetings] = useState([]);
  const [error, setError] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [newMeetingSuccess, setNewMeetingSuccess] = useState(false);
  const [loading, setLoading] = useState(false); // Loader state
  const [updateNotesModal, setUpdateNotesModal] = useState(false); // Modal for updating notes
  const [selectedMeetingId, setSelectedMeetingId] = useState(null); // ID of the meeting to update
  const [progressNotes, setProgressNotes] = useState(""); // New notes to update

  useEffect(() => {
    const fetchMeetings = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meetings/${mentor_id}`);
        if (!response.ok) throw new Error("Failed to fetch meetings");
        const data = await response.json();
        setMeetings(data.meetings || []);
      } catch (err) {
        setError(err.message || "Error fetching meetings");
      }
    };

    fetchMeetings();
  }, [mentor_id, newMeetingSuccess]);

  useEffect(() => {
    const fetchAssignedStudents = async () => {
      try {
        const response = await fetch(
          `${API_BASE_URL}/mentor/${mentor_id}/assigned_students`
        );
        if (!response.ok) throw new Error("Failed to fetch students");
        const data = await response.json();
        setAssignedStudents(
          data.map((student) => ({
            value: student.student_usn,
            label: `${student.student_name} (${student.student_usn})`,
          }))
        );
      } catch (err) {
        setError(err.message || "Error fetching students");
      }
    };

    fetchAssignedStudents();
  }, [mentor_id]);

  const handleUpdateNotes = async () => {
    if (!progressNotes) {
      alert("Please enter the progress notes!");
      return;
    }

    try {
      const response = await fetch(
        `${API_BASE_URL}/log_meeting/${mentor_id}/${selectedMeetingId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ progress_notes: progressNotes }),
        }
      );

      if (!response.ok) throw new Error("Failed to update notes");

      alert("Meeting progress notes updated successfully!");

      setMeetings((prevMeetings) =>
        prevMeetings.map((meeting) =>
          meeting.meeting_id === selectedMeetingId
            ? { ...meeting, progress_notes: progressNotes }
            : meeting
        )
      );
      setUpdateNotesModal(false); // Close the modal after update
    } catch (err) {
      setError(err.message || "Error updating notes");
    }
  };

  const handleScheduleMeeting = async () => {
    if (selectedStudents.length === 0 || !meetingDate || !venue) {
      alert("Please fill out all fields!");
      return;
    }

    setLoading(true); // Start loading
    setError(""); // Clear any previous errors

    try {
      const formattedDate = new Date(meetingDate).toISOString().slice(0, 16);
      const studentUsns = selectedStudents.map((student) => student.value);

      const response = await fetch(`${API_BASE_URL}/schedule_meeting/${mentor_id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          meeting_date: formattedDate,
          venue: venue,
          student_usns: studentUsns,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || "Failed to schedule meeting");
      }

      alert("Meetings scheduled successfully!");
      setNewMeetingSuccess(true);
      setShowModal(false);
      setSelectedStudents([]); // Clear selection
      setMeetingDate("");
      setVenue("");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false); // Stop loading
    }
  };

  const convertToLocalTime = (utcDate) => {
    if (!utcDate) return "Invalid Date";

    return new Date(utcDate).toLocaleString("en-IN", {
      timeZone: "Asia/Kolkata",
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  return (
    <div>
      <h1 className="meetings__title">Meetings with Mentor: {mentor_id}</h1>
      {error && <p className="meetings__error">{error}</p>}

      <button
        className="meetings__button meetings__button--schedule"
        onClick={() => setShowModal(true)}
      >
        Schedule New Meeting
      </button>

      {showModal && (
        <div className="meetings__modal">
          <div className="meetings__modal-content">
            <h2 className="meetings__modal-title">Schedule New Meeting</h2>

            <Select
  className="meetings__dropdown"
  options={[
    { value: "all", label: "Select All" }, // Add "Select All" option
    ...assignedStudents,
  ]}
  isMulti
  placeholder="Select Students"
  value={selectedStudents}
  onChange={(selectedOptions) => {
    if (selectedOptions.some((option) => option.value === "all")) {
      setSelectedStudents(assignedStudents); // Select all students
    } else {
      setSelectedStudents(selectedOptions); // Set selected students
    }
  }}
/>

            <input
              className="meetings__input meetings__input--datetime"
              type="datetime-local"
              value={meetingDate}
              onChange={(e) => setMeetingDate(e.target.value)}
            />

            <input
              className="meetings__input"
              type="text"
              placeholder="Venue"
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
            />

            <button
              className="meetings__button meetings__button--submit"
              onClick={handleScheduleMeeting}
              disabled={loading} // Disable button while loading
            >
              {loading ? "Scheduling..." : "Schedule Meeting"} {/* Show loader text */}
            </button>
            <button
              className="meetings__button meetings__button--close"
              onClick={() => setShowModal(false)}
              disabled={loading} // Disable closing while loading
            >
              Close
            </button>
          </div>
        </div>
      )}

      {updateNotesModal && (
        <div className="meetings__modal">
          <div className="meetings__modal-content">
            <h2 className="meetings__modal-title">Update Progress Notes</h2>

            <textarea
              className="meetings__input"
              placeholder="Enter progress notes..."
              value={progressNotes}
              onChange={(e) => setProgressNotes(e.target.value)}
            ></textarea>

            <button
              className="meetings__button meetings__button--submit"
              onClick={handleUpdateNotes}
            >
              Update Notes
            </button>
            <button
              className="meetings__button meetings__button--close"
              onClick={() => setUpdateNotesModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      <h2 className="meetings__list-title">Existing Meetings</h2>
      {meetings.length === 0 ? (
        <p className="meetings__no-records">No meetings found for this mentor.</p>
      ) : (
        <div className="meetings__table-container">
          <table className="meetings__table">
            <thead>
              <tr className="meetings__table-header">
                <th>Student USN</th>
                <th>Meeting Date</th>
                <th>Venue</th>
                <th>Progress Notes</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {meetings.map((meeting) => (
                <tr key={meeting.meeting_id}>
                  <td>{meeting.student_usn}</td>
                  <td>{convertToLocalTime(meeting.meeting_date)}</td>
                  <td>{meeting.venue}</td>
                  <td>{meeting.progress_notes || "N/A"}</td>
                  <td>
                    <button
                      className="meetings__button meetings__button--update"
                      onClick={() => {
                        setSelectedMeetingId(meeting.meeting_id);
                        setProgressNotes(meeting.progress_notes || "");
                        setUpdateNotesModal(true);
                      }}
                    >
                      Update Notes
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <br />
          <br />
        </div>
      )}
    </div>
  );
};

export default Meetings;
