import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../../../assets/css/AssignedStudents.css';
import { API_BASE_URL } from "../../../api";
import * as XLSX from 'xlsx';

const AssignedStudents = () => {
  const { mentor_id } = useParams();
  const [students, setStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [programFilter, setProgramFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [programs, setPrograms] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [searchUSN, setSearchUSN] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState(null);
  const [loadingStats, setLoadingStats] = useState(false);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/mentor/${mentor_id}/assigned_students`);
        if (!response.ok) {
          throw new Error('No students have been assigned yet.');
        }
        const data = await response.json();
        setStudents(data);
        setFilteredStudents(data);
        const uniquePrograms = Array.from(new Set(data.map(student => student.program)));
        setPrograms(uniquePrograms);
        const uniqueStatuses = Array.from(new Set(data.map(student => student.status)));
        setStatuses(uniqueStatuses);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchStudents();
  }, [mentor_id]);

  const fetchStats = async () => {
    setLoadingStats(true);
    try {
      const response = await fetch(`${API_BASE_URL}/mentor/${mentor_id}/student_stats`);
      if (!response.ok) {
        throw new Error('Error fetching statistics');
      }
      const data = await response.json();
      setStats(data);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoadingStats(false);
    }
  };

  const applyFilters = (program, usn, status) => {
    let filtered = students;
    if (program) {
      filtered = filtered.filter(student => student.program === program);
    }
    if (usn) {
      filtered = filtered.filter(student => student.student_usn.includes(usn));
    }
    if (status) {
      filtered = filtered.filter(student => student.status === status);
    }
    setFilteredStudents(filtered);
  };

  const handleProgramFilterChange = (e) => {
    const selectedProgram = e.target.value;
    setProgramFilter(selectedProgram);
    applyFilters(selectedProgram, searchUSN, statusFilter);
  };

  const handleStatusFilterChange = (e) => {
    const selectedStatus = e.target.value;
    setStatusFilter(selectedStatus);
    applyFilters(programFilter, searchUSN, selectedStatus);
  };

  const handleSearchChange = (e) => {
    const searchValue = e.target.value;
    setSearchUSN(searchValue);
    applyFilters(programFilter, searchValue, statusFilter);
  };

  const downloadExcel = () => {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(filteredStudents);
    XLSX.utils.book_append_sheet(wb, ws, 'Students');
    XLSX.writeFile(wb, 'students.xlsx');
  };

  if (isLoading) return <div>Loading assigned students...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div className="assigned-students__container">
      <h2 className="assigned-students__title">Assigned Students</h2>
      <div className="assigned-students__filter">
        {/* ... (filter and search inputs) */}
        <label htmlFor="programFilter">Filter by Program:</label>
        <select id="programFilter" value={programFilter} onChange={handleProgramFilterChange}>
          <option value="">All Programs</option>
          {programs.map((program, index) => (
            <option key={index} value={program}>{program}</option>
          ))}
        </select>

        <label htmlFor="statusFilter">Filter by Status:</label>
        <select id="statusFilter" value={statusFilter} onChange={handleStatusFilterChange}>
          <option value="">All Statuses</option>
          {statuses.map((status, index) => (
            <option key={index} value={status}>{status}</option>
          ))}
        </select>

        <label htmlFor="searchUSN">Search by USN:</label>
        <input
          type="text"
          id="searchUSN"
          value={searchUSN}
          onChange={handleSearchChange}
          placeholder="Enter USN"
        />

      </div>
      <div className="button-group"> {/* Container for buttons */}
        <button className="stats-btn" onClick={fetchStats} disabled={loadingStats}>
          {loadingStats ? 'Showing... Please wait' : 'Show Stats'}
        </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button className="download-btn" onClick={downloadExcel}>Download Excel</button> {/* Download Button */}
      </div>
       {/* ... (student count and stats display) */}
       <div className="student-count">
        <strong>
          Total number of students in
          <span className="highlight-text"> {programFilter ? programFilter : "All Programs"} </span>
          at
          <span className="highlight-text"> {statusFilter ? statusFilter : "All Statuses"} </span>:
          &nbsp;{filteredStudents.length}
        </strong>
      </div>

      {stats && (
        <div className="mentor-stats">
          <h3>Statistics</h3>
          <div className="mstats-circles">
            {/* ... (stats circles) */}
            <div className="mstat-circle">
              <div className="mcircle">{stats.total_students}</div>
              <p>Total Students</p>
            </div>
            <div className="mstat-circle">
              <div className="mcircle">{stats.psychometric_form_filled}</div>
              <p>Psychometric Forms Filled</p>
            </div>
            <div className="mstat-circle">
              <div className="mcircle">{stats.report_generated}</div>
              <p>Reports Generated</p>
            </div>
            <div className="mstat-circle">
              <div className="mcircle">{stats.activities_generated}</div>
              <p>Activities Generated</p>
            </div>
          </div>
        </div>
      )}

      <div className="assigned-students__table-container">
        {/* ... (table display) */}
        <table className="assigned-students__table">
          <thead>
            <tr>
              {/* ... (table headers) */}
              <th>USN</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Program</th>
              <th>LinkedIn</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredStudents.map(student => (
              <tr key={student.student_usn}>
                {/* ... (table cells) */}
                <td>{student.student_usn}</td>
                <td>{student.student_name}</td>
                <td>{student.phone}</td>
                <td>{student.email}</td>
                <td>{student.program}</td>
                <td>
                  <a href={student.linkedin} target="_blank" rel="noopener noreferrer">
                    {student.linkedin ? 'Profile' : 'N/A'}
                  </a>
                </td>
                <td>{student.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AssignedStudents;