import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../../../assets/css/Report.css';  // New CSS file for unique styles
import { API_BASE_URL } from '../../../api';

const ReportPage = () => {
    const { student_usn } = useParams();  // Extract student_usn from the URL
    const [report, setReport] = useState(null);

    useEffect(() => {
        fetch(`${API_BASE_URL}/swot-report/${student_usn}`)
            .then((response) => response.json())
            .then((data) => {
                // Check if the data contains the necessary SWOT fields
                if (data.strengths || data.weaknesses || data.opportunities || data.threats) {
                    setReport(data);
                } else {
                    setReport({}); // Set an empty object if no relevant data is found
                }
            })
            .catch((error) => console.error('Error fetching the report:', error));
    }, [student_usn]);

    if (report === null) {
        return <p className="report-loading">Loading report...</p>;
    }

    if (Object.keys(report).length === 0) {
        // Display message when no SWOT report is found
        return <div className="no-report-found">No SWOT report found for this student.</div>;
    }

    return (
        <div className="report-container">
            <h1 className="report-title">SWOT Report</h1>
            <div className="report-content">
                <div className="swot-quadrants">
                    <div className="swot-quadrant strengths">
                        <h3>Strengths</h3>
                        <p>{report.strengths}</p>
                    </div>
                    <div className="swot-quadrant weakness">
                        <h3>Weaknesses</h3>
                        <p>{report.weaknesses}</p>
                    </div>

                    <div className="swot-quadrant opportunities">
                        <h3>Opportunities</h3>
                        <p>{report.opportunities}</p>
                    </div>
                    <div className="swot-quadrant threats">
                        <h3>Threats</h3>
                        <p>{report.threats}</p>
                    </div>
                </div>

                <div className="additional-info">
                    <p><strong>Professional Aspirations:</strong> {report.professional_aspirations}</p>
                    <p><strong>Hobbies/Interests:</strong> {report['hobbies/interests']}</p>
                    <p><strong>Detailed Analysis:</strong> {report.detailed_analysis}</p>
                </div>
            </div><br/><br/><br/><br/><br/><br/><br/><br/>
        </div>
    );
};

export default ReportPage;
