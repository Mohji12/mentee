import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import '../../../assets/css/StudentMeetings.css'; // Import unique CSS file
import { API_BASE_URL } from "../../../api";

const StudentMeetings = () => {
  const { student_usn } = useParams(); // Extract student_usn from the URL
  const [meetings, setMeetings] = useState([]);
  const [error, setError] = useState("");

  // Fetch the existing meetings when the component loads
  useEffect(() => {
    const fetchMeetings = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meetings/student/${student_usn}`);
        if (!response.ok) throw new Error("Failed to fetch meetings");
        const data = await response.json();
        
        // Adjust the meeting date by adding 5 hours and 30 minutes
        const updatedMeetings = data.meetings.map(meeting => {
          const meetingDate = new Date(meeting.meeting_date);
          meetingDate.setHours(meetingDate.getHours() + 5);
          meetingDate.setMinutes(meetingDate.getMinutes() + 30);
          
          // Format the date in your preferred format
          meeting.meeting_date = meetingDate.toLocaleString(); // Adjust as needed
          
          return meeting;
        });

        setMeetings(updatedMeetings);
      } catch (err) {
        setError("Failed to fetch meetings");
      }
    };

    fetchMeetings();
  }, [student_usn]); // Trigger refresh on student_usn change

  return (
    <div className="student-meetings-container">
      {error && <p className="student-meetings-error">{error}</p>}
      {meetings.length === 0 ? (
        <p className="student-meetings-no-schedule">No meetings being scheduled.</p>
      ) : (
        <div className="student-meetings-table-container">
          <table className="student-meetings-table">
            <thead>
              <tr>
                <th className="student-meetings-header">Meeting ID</th>
                <th className="student-meetings-header">Mentor ID</th>
                <th className="student-meetings-header">Meeting Date</th>
                <th className="student-meetings-header">Venue</th>
                <th className="student-meetings-header">Progress Notes</th>
              </tr>
            </thead>
            <tbody>
              {meetings.map((meeting) => (
                <tr key={meeting.meeting_id} className="student-meetings-row">
                  <td className="student-meetings-cell">{meeting.meeting_id}</td>
                  <td className="student-meetings-cell">{meeting.mentor_id}</td>
                  <td className="student-meetings-cell">{meeting.meeting_date}</td>
                  <td className="student-meetings-cell">{meeting.venue}</td>
                  <td className="student-meetings-cell">{meeting.progress_notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default StudentMeetings;
