import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../../../assets/css/Activities.css'; // Make sure to include the new CSS file
import { API_BASE_URL } from '../../../api';

const ActivitiesPage = () => {
  const { student_usn } = useParams();
  const [activities, setActivities] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/activities/${student_usn}`);
        if (response.status === 404) {
          // Handle case when no activities are found
          setActivities([]);
          return;
        }
        if (!response.ok) {
          throw new Error('Failed to fetch activities');
        }
        const data = await response.json();
        setActivities(data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchActivities();
  }, [student_usn]);

  if (error) {
    return <div className="activities-page-error">Error: {error}</div>;
  }

  if (activities === null) {
    return <div className="activities-page-loading">Loading...</div>;
  }

  const noActivities =
    !activities.short_term &&
    !activities.short_term1 &&
    !activities.short_term2 &&
    !activities.mid_term &&
    !activities.mid_term1 &&
    !activities.mid_term2 &&
    !activities.long_term &&
    !activities.long_term1 &&
    !activities.long_term2;

  if (noActivities) {
    return <div className="activities-page-empty">No activities found for this student.</div>;
  }

  return (
    <div className="activities-page-container">
      <h1 className="activities-page-title">Activities for {student_usn}</h1>

      <div className="activities-section">
        <h3 className="activities-subtitle">Short Term Activities</h3>
        <div className="activities-list">
          {activities.short_term && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.short_term}</span>
            </div>
          )}
          {activities.short_term1 && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.short_term1}</span>
            </div>
          )}
          {activities.short_term2 && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.short_term2}</span>
            </div>
          )}
        </div>
      </div>

      <div className="activities-section">
        <h3 className="activities-subtitle">Mid Term Activities</h3>
        <div className="activities-list">
          {activities.mid_term && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.mid_term}</span>
            </div>
          )}
          {activities.mid_term1 && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.mid_term1}</span>
            </div>
          )}
          {activities.mid_term2 && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.mid_term2}</span>
            </div>
          )}
        </div>
      </div>

      <div className="activities-section">
        <h3 className="activities-subtitle">Long Term Activities</h3>
        <div className="activities-list">
          {activities.long_term && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.long_term}</span>
            </div>
          )}
          {activities.long_term1 && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.long_term1}</span>
            </div>
          )}
          {activities.long_term2 && (
            <div className="activities-row">
              <input type="checkbox" className="activities-checkbox" />
              <span className="activities-item">{activities.long_term2}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ActivitiesPage;
