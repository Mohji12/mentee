import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import '../../../assets/css/StudentLoggedActivities.css';  // Add new CSS file
import { API_BASE_URL } from "../../../api";

const StudentLoggedActivities = () => {
  const { student_usn } = useParams();
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchLoggedActivities = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/student/${student_usn}/logged_activities`);
        if (!response.ok) {
          if (response.status === 404) {
            setActivities([]);
          } else {
            throw new Error("Failed to fetch activities");
          }
        } else {
          const data = await response.json();
          console.log(data);  // Check the data received here
          setActivities(data.activities);
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    
    fetchLoggedActivities();
  }, [student_usn]);

  if (loading) return <div className="student-activities-loading">Loading activities...</div>;
  if (error) return <div className="student-activities-error">Error: {error}</div>;
  if (activities.length === 0) return <div className="student-activities-no-data">Activities not generated yet.</div>;

  return (
    <div className="student-activities-container">
      <h2 className="student-activities-title">Logged Activities</h2>
      {activities.length === 0 ? (
        <p className="student-activities-empty">No activities logged for this student.</p>
      ) : (
        <table className="student-activities-table">
          <thead>
            <tr>
              <th className="student-activities-table-header">Activity ID</th>
              <th className="student-activities-table-header">Activity</th>
              <th className="student-activities-table-header">Duration Type</th>
              <th className="student-activities-table-header">Deadline</th>
              <th className="student-activities-table-header">Remarks</th>
              <th className="student-activities-table-header">Completed In</th>
              <th className="student-activities-table-header">Benefitted</th>
              <th className="student-activities-table-header">Proof</th> {/* New column for proof */}
            </tr>
          </thead>
          <tbody>
            {activities.map((activity) => (
              <tr key={activity.activity_id} className="student-activities-table-row">
                <td className="student-activities-table-data">{activity.activity_id}</td>
                <td className="student-activities-table-data">{activity.activities}</td>
                <td className="student-activities-table-data">{activity.duration_type}</td>
                <td className="student-activities-table-data">{new Date(activity.deadline).toLocaleDateString()}</td>
                <td className="student-activities-table-data">{activity.remarks || "N/A"}</td>
                <td className="student-activities-table-data">{activity.completed_in || "N/A"}</td>
                <td className="student-activities-table-data">{activity.benefitted ? "Yes" : "No"}</td>
                <td className="student-activities-table-data">
                  {activity.proof ? (
                    <a href={activity.proof} target="_blank" rel="noopener noreferrer">View Proof</a> // Display proof if available
                  ) : (
                    "No proof provided" // If no proof is available
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}<br/><br/><br/><br/><br/><br/>
    </div>
  );
};

export default StudentLoggedActivities;
