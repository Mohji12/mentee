import React, { useState, useEffect, useRef } from 'react';
import { Link, useParams } from 'react-router-dom';
import '../../../assets/css/StudentSidebar.css';
import { FaUser, FaClipboardList, FaChartLine, FaTasks, FaRegClock, FaChevronDown, FaChevronUp } from 'react-icons/fa';

const StudentSidebar = () => {
  const { student_usn } = useParams(); // Fetch the student USN from the URL
  const [activitiesDropdown, setActivitiesDropdown] = useState(false);
  const sidebarRef = useRef(); // Reference for sidebar container

  const toggleDropdown = () => {
    setActivitiesDropdown(!activitiesDropdown);
  };

  // Close dropdown if clicked outside or on another menu item
  const closeDropdown = () => {
    setActivitiesDropdown(false);
  };

  // Close dropdown if clicked outside the sidebar
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        setActivitiesDropdown(false); // Close the dropdown if clicked outside
      }
    };

    // Add event listener for clicks
    document.addEventListener('mousedown', handleClickOutside);

    // Cleanup the event listener on component unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div ref={sidebarRef} className="ss-sidebar-container">
      <Link to={`/student/${student_usn}/profile`}>
        <div className="ss-logo-left ss-logo-mobile-left"></div>
      </Link>
      <ul className="ss-sidebar-menu">
        {/* Form */}
        <li>
          <Link to={`/student/${student_usn}/psychometric`} className="ss-sidebar-menu-item" onClick={closeDropdown}>
            <FaClipboardList />&nbsp;&nbsp;&nbsp;&nbsp;Form
          </Link>
        </li>

        {/* Report */}
        <li>
          <Link to={`/student/${student_usn}/report`} className="ss-sidebar-menu-item" onClick={closeDropdown}>
            <FaChartLine />&nbsp;&nbsp;&nbsp;&nbsp;Report
          </Link>
        </li>

        {/* Activities Dropdown */}
        <li className="ss-dropdown-container">
          <div className="ss-sidebar-menu-item" onClick={toggleDropdown}>
            <FaTasks />&nbsp;&nbsp;&nbsp;&nbsp;Activities {activitiesDropdown ? <FaChevronUp /> : <FaChevronDown />}
          </div>
          {activitiesDropdown && (
            <ul className="ss-dropdown-menu">
              <li>
                <Link to={`/student/${student_usn}/activities`} className="ss-dropdown-menu-item" onClick={closeDropdown}>
                  Assigned Activities
                </Link>
              </li>
              <li>
                <Link to={`/student/${student_usn}/logged_activities`} className="ss-dropdown-menu-item" onClick={closeDropdown}>
                  Logged Activities
                </Link>
              </li>
            </ul>
          )}
        </li>

        {/* Meetings */}
        <li>
          <Link to={`/student/${student_usn}/scheduled_meetings`} className="ss-sidebar-menu-item" onClick={closeDropdown}>
            <FaRegClock />&nbsp;&nbsp;&nbsp;&nbsp;Meetings
          </Link>
        </li>

        {/* Profile */}
        <li>
          <Link to={`/student/${student_usn}/profile`} className="ss-sidebar-menu-item" onClick={closeDropdown}>
            <FaUser />&nbsp;&nbsp;&nbsp;&nbsp;Profile
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default StudentSidebar;
