import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import '../../../assets/css/StudentProfile.css';
import { API_BASE_URL } from '../../../api';
import { Link } from 'react-router-dom';
import { FaSignOutAlt, FaPen } from 'react-icons/fa'; // Import pencil icon

const StudentProfile = () => {
  const { student_usn } = useParams();
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false); // Modal state
  const [formData, setFormData] = useState({
    student_name: '',
    linkedin: ''
  }); // State for the form data
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`${API_BASE_URL}/student/profile/${student_usn}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Profile not found');
        }
        return response.json();
      })
      .then((data) => {
        setProfile(data);
        setFormData({
          student_name: data.student_name || '',
          linkedin: data.linkedin || ''
        });
        setIsLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching profile:', error);
        setIsLoading(false);
      });
  }, [student_usn]);

  const handleCreateProfile = () => {
    navigate(`/student/${student_usn}/createprofile`);
  };

  const handleEditProfile = () => {
    // Make PUT request to update profile
    fetch(`${API_BASE_URL}/student/profile/edit/${student_usn}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Profile updated:', data);
        setIsModalOpen(false); // Close modal after update
        fetchProfile(); // Re-fetch profile after update
      })
      .catch((error) => console.error('Error updating profile:', error));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const renderLinkedInButton = (linkedin) => {
    if (!linkedin) return null;
    const linkedinPattern = /^(https?:\/\/)?(www\.)?linkedin\.com\/in\/([a-zA-Z0-9-]+)(\/)?(\?.*)?$/;
    const isValidLinkedIn = linkedinPattern.test(linkedin);

    return isValidLinkedIn ? (
      <a href={linkedin} target="_blank" rel="noopener noreferrer" className="sp-profile-linkedin-btn">
        View
      </a>
    ) : (
      <p className="sp-profile-error">Invalid LinkedIn URL format</p>
    );
  };

  const fetchProfile = () => {
    fetch(`${API_BASE_URL}/student/profile/${student_usn}`)
      .then((response) => response.json())
      .then((data) => setProfile(data));
  };

  if (isLoading) {
    return <div className="sp-profile-loading">Loading...</div>;
  }

  return (
    <div className='sp-details-profile'>
      <div className="sp-profile-header"><br/><br/>
        <h2 className="sp-profile-title">
          Profile&nbsp;&nbsp;&nbsp;&nbsp;
          <FaPen className="sp-profile-edit-icon" onClick={() => setIsModalOpen(true)} />
        </h2>
      </div>
      
      {profile && profile.student_name ? (
        <div className="sp-profile-details-container">
          <div className="sp-profile-details">
            <p><span className="sp-profile-label">USN:</span> {profile.student_usn}{' '}</p>
            <p><span className="sp-profile-label">Name:</span> {profile.student_name}</p>
            <p><span className="sp-profile-label">Email:</span> {profile.student_email}</p>
            <p><span className="sp-profile-label">Phone Number:</span> {profile.student_phoneno}</p>
            <p><span className="sp-profile-label">Program:</span> {profile.student_program}</p>
            <p><span className="sp-profile-label">Batch:</span> {profile.student_batch}</p>
            <p><span className="sp-profile-label">Semester:</span> {profile.semester}</p>
            <p><span className="sp-profile-label">Assigned Mentor:</span> {profile.assigned_mentor}</p>
            <p><span className="sp-profile-label">LinkedIn:</span> {renderLinkedInButton(profile.linkedin)}</p>
            <button className="sp-sidebar-logout-button">
              <Link to={`/logout`} className="sp-sidebar-logout-link">
                <FaSignOutAlt /> Logout
              </Link>
            </button><br/><br/><br/><br/>
          </div>
        </div>
      ) : (
        <div><br/><br/>
          <p>No profile found.</p>
          <button className="sp-profile-create-button" onClick={handleCreateProfile}>Create Profile</button>
          <button className="sp-sidebar-logout-button">
              <Link to={`/logout`} className="sp-sidebar-logout-link">
                <FaSignOutAlt /> Logout
              </Link>
          </button><br/><br/><br/><br/>
        </div>
      )}

      {isModalOpen && (
        <div className="sp-profile-modal">
          <div className="sp-profile-modal-content">
            <h3>Edit Profile</h3>
            <label>Name:</label>
            <input
              type="text"
              name="student_name"
              value={formData.student_name}
              onChange={handleInputChange}
            />
            <label>LinkedIn:</label>
            <input
              type="text"
              name="linkedin"
              value={formData.linkedin}
              onChange={handleInputChange}
            />
            <div className="sp-profile-buttons-container">
              <button onClick={handleEditProfile}>Save Changes</button>
              <button onClick={() => setIsModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentProfile;