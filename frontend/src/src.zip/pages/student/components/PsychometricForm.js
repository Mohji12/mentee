import React, { useState } from "react";
import { useParams } from "react-router-dom"; 
import '../../../assets/css/Psychometric.css'; // Updated unique CSS
import { API_BASE_URL } from "../../../api";

const PsychometricForm = () => {
  const { student_usn } = useParams(); 
  const [formData, setFormData] = useState({
    present_address: "",
    permanent_address: "",
    educational_qualifications: "",
    subjects_strength: "",
    subjects_weakness: "",
    previous_work_experience: "",
    father_name: "",
    father_mobile_no: "",
    father_education: "",
    father_employment: "",
    mother_name: "",
    mother_mobile_no: "",
    mother_education: "",
    mother_employment: "",
    siblings_details: "",
    professional_dream: "",
    professional_fear: "",
    happiness_sources: "",
    expectations: "",
    goal_achieving_opportunities: "",
    participate_in_skill_programs: false,
    interested_skill_programs: "",
    external_factors_affecting_growth: "",
    primary_stressors: "",
    biggest_distractions: "",
    strongest_skills: "",
    areas_of_low_confidence: "",
    hobbies_interests: "",
    consent_given: true,
  });

  const [status, setStatus] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const pageFields = {
    1: ["present_address", "permanent_address"],
    2: ["educational_qualifications", "subjects_strength", "subjects_weakness", "previous_work_experience"],
    3: ["father_name", "father_mobile_no", "father_education", "father_employment", "mother_name", "mother_mobile_no", "mother_education", "mother_employment", "siblings_details"],
    4: ["professional_dream", "professional_fear", "happiness_sources"],
    5: ["expectations", "goal_achieving_opportunities", "participate_in_skill_programs", "interested_skill_programs"],
    6: ["external_factors_affecting_growth","primary_stressors", "biggest_distractions"],
    7: ["strongest_skills","areas_of_low_confidence","hobbies_interests"],
    8: ["consent_given"]
  };

  const validatePageFields = () => {
    const fieldsToValidate = pageFields[currentPage];
    return fieldsToValidate.every((field) => {
      return formData[field] !== "" && formData[field] !== null && formData[field] !== undefined;
    });
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevFormData) => {
      const updatedFormData = {
        ...prevFormData,
        [name]: type === "checkbox" ? checked : value,
      };

      // Revalidate fields and clear error message if valid
      if (validatePageFields()) {
        setStatus("");
      }
      return updatedFormData;
    });
  };

  const handleNext = () => {
    if (validatePageFields()) {
      if (currentPage < 8) {
        setCurrentPage(currentPage + 1);
      }
    } else {
      setStatus("Please fill all required fields on this page.");
    }
  };

  const handlePrev = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`${API_BASE_URL}/student/psychometric-form/${student_usn}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.message) {
          setStatus("Form submitted successfully.");
        } else {
          throw new Error(data.detail || "Submission failed.");
        }
      })
      .catch((error) => {
        if (error.message === "Psychometric form already submitted for this semester") {
          setStatus("You have already submitted the psychometric form for this semester.");
        } else {
          setStatus(`Error: ${error.message}`);
        }
      });
  };
  return (
    <div className="form-container-unique">
      <h2 className="psychometric-title-unique">SWOT Analysis</h2>
      <form onSubmit={handleSubmit}>
        {/* Personal Information Section */}
        {currentPage === 1 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Personal Information</h3>
            <label>
              Present Address:
              <input
                type="text"
                name="present_address"
                value={formData.present_address}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Current Address"
              />
            </label>
            <label>
              Permanent Address:
              <input
                type="text"
                name="permanent_address"
                value={formData.permanent_address}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Permanent Address"
              />
            </label>
          </div>
        )}

        {/* Educational Details Section */}
        {currentPage === 2 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Educational Background</h3>
            <label>
              Educational Qualifications:
              <input
                type="text"
                name="educational_qualifications"
                value={formData.educational_qualifications}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="List your highest Qualifications."
              />
            </label>
            <label>
              Strengths in Subjects:
              <input
                type="text"
                name="subjects_strength"
                value={formData.subjects_strength}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Which subjects do you excel in? List Out"
              />
            </label>
            <label>
              Weaknesses in Subjects:
              <input
                type="text"
                name="subjects_weakness"
                value={formData.subjects_weakness}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Which subjects do you struggle with? List out"
              />
            </label>
            <label>
              Previous Work Experience:
              <input
                type="text"
                name="previous_work_experience"
                value={formData.previous_work_experience}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Describe any work experience you have, if applicable."
              />
            </label>
          </div>
        )}

        {/* Family Information Section */}
        {currentPage === 3 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Family Background</h3>
            <label>
              Father's Name:
              <input
                type="text"
                name="father_name"
                value={formData.father_name}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Father's Name"
              />
            </label>
            <label>
              Father's Mobile Number:
              <input
                type="tel"
                name="father_mobile_no"
                value={formData.father_mobile_no}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Father's Mobile No."
                maxLength="10"
              />
            </label>
            <label>
              Father's Education:
              <input
                type="text"
                name="father_education"
                value={formData.father_education}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What is your father's highest educational qualification?"
              />
            </label>
            <label>
              Father's Employment:
              <input
                type="text"
                name="father_employment"
                value={formData.father_employment}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What is your father's occupation?"
              />
            </label>
            <label>
              Mother's Name:
              <input
                type="text"
                name="mother_name"
                value={formData.mother_name}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Mother's Name"
              />
            </label>
            <label>
              Mother's Mobile Number:
              <input
                type="tel"
                name="mother_mobile_no"
                value={formData.mother_mobile_no}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Mother's Mobile No."
                maxLength="10"
              />
            </label>
            <label>
              Mother's Education:
              <input
                type="text"
                name="mother_education"
                value={formData.mother_education}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What is your mother's highest educational qualification?"
              />
            </label>
            <label>
              Mother's Employment:
              <input
                type="text"
                name="mother_employment"
                value={formData.mother_employment}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What is your mother's occupation?"
              />
            </label>
            <label>
              Sibling's Details:
              <input
                type="text"
                name="siblings_details"
                value={formData.siblings_details}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Do you have siblings? If yes, mention their occupation or educational status."
              />
            </label>
          </div>
        )}

        {/* Goals and Interests Section */}
        {currentPage === 4 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Professional Aspirations</h3>
            <label>
              What is your professional dream?
              <input
                type="text"
                name="professional_dream"
                value={formData.professional_dream}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Describe your career aspirations."
              />
            </label>
            <label>
              What is your biggest fear?
              <input
                type="text"
                name="professional_fear"
                value={formData.professional_fear}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What challenges or fears do you think might affect your career goals?"
              />
            </label>
            <label>
              What is your happiness in your personal/professional life?
              <input
                type="text"
                name="happiness_sources"
                value={formData.happiness_sources}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What activities, achievements, or experience make you happy?"
              />
            </label>
          </div>
        )}

        {/* Goals and Interests Section */}
        {currentPage === 5 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Opportunites and Expectations</h3>
            <label>
              What are your expectations when joining JAIN (Deemed-to-be University)? 
              <input
                type="text"
                name="expectations"
                value={formData.expectations}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="What do you hope to achieve academically and personally during your time at the university?"
              />
            </label>
            <label>
              What opportunities do you think will help you achieve your goals?
              <input
                type="text"
                name="goal_achieving_opportunities"
                value={formData.goal_achieving_opportunities}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="List the resources, programs, or experiences you believe will benefit you."
              />
            </label>
            <label>
              Would you like to participate in additional skills-building programs?
              <input
                type="checkbox"
                name="participate_in_skill_programs"
                value={formData.participate_in_skill_programs}
                onChange={handleChange}
                required
                className="checkbox-field-unique"
              />
            </label><br/><br/>
            <label>  
              If yes, what kind of skill-building programs are you looking for/ are interested in 
              <input
                type="text"
                name="interested_skill_programs"
                value={formData.interested_skill_programs}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="List out the interested skill building programs."
              />
            </label>
          </div>
        )}

        {/* Goals and Interests Section */}
        {currentPage === 6 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Challenges</h3>
            <label>
              What external factors that you think might affect your academic growth? 
              <input
                type="text"
                name="external_factors_affecting_growth"
                value={formData.external_factors_affecting_growth}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="For eg. family responsibilities, financial issues, etc."
              />
            </label>
            <label>
              What are your primary stressors?
              <input
                type="text"
                name="primary_stressors"
                value={formData.primary_stressors}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="List situations or tasks that cause you the most stress."
              />
            </label>
            <label>
              What do you consider the biggest distractions in your life right now?
              <input
                type="text"
                name="biggest_distractions"
                value={formData.biggest_distractions}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="For eg, social media, peer pressur, etc."
              />
            </label>
          </div>
        )}

        {/* Goals and Interests Section */}
        {currentPage === 7 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Skills and Interests</h3>
            <label>
              What according to you, are your strongest skills? 
              <input
                type="text"
                name="strongest_skills"
                value={formData.strongest_skills}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Mention any skills you feel particularly confident in."
              />
            </label>
            <label>
              What areas do you feel less confident? 
              <input
                type="text"
                name="areas_of_low_confidence"
                value={formData.areas_of_low_confidence}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Describe skills or ares where you think you need improvement."
              />
            </label>
            <label>
              What are your hobbies or extracurricular interests?
              <input
                type="text"
                name="hobbies_interests"
                value={formData.hobbies_interests}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="List any activities or interests you enjoy outside academics."
              />
            </label>
          </div>
        )}

        {/* Goals and Interests Section */}
        {currentPage === 8 && (
          <div className="form-section-unique">
            <h3 className="section-title-unique">Consent</h3>
            <label>
            <input
                type="radio" 
                name="consent_given"
                value={formData.consent_given}
                onChange={handleChange}
                required
                className="input-field-unique"
                placeholder="Mention any skills you feel particularly confident in."
              />
            I hereby consent to the collection and analysis of my personal, academic, and professional data for the purpose of conducting a SWOT (Strengths, Weaknesses, Opportunities, and Threats) analysis. I understand that this analysis is intended to support my academic and personal growth. I acknowledge that this data may also be shared with designated university officials/ my mentor/ mentorship coordinator for analysis and academic purposes. I understand that all collected data will be kept confidential, securely stored, and used solely for educational and institutional purposes. Additionally, I recognize that all data provided is the proprietary property of JAIN (Deemed-to-be University) and will be handled in accordance with the university's data protection and privacy policies.
            </label>
            </div>
        )}

        <div className="form-navigation-buttons">
          {currentPage > 1 && (
            <button type="button" onClick={handlePrev} className="nav-button-unique">
              Previous
            </button>
          )}
          {currentPage < 8 ? (
            <button type="button" onClick={handleNext} className="nav-button-unique">
              Next
            </button>
          ) : (
            <button type="submit" className="submit-button-unique">
              Submit
            </button>
          )}
        </div><br/><br/>
        {status && <p className="status-message-unique">{status}</p>}
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
      </form>
    </div>
  );
};

export default PsychometricForm;
