import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import '../../../assets/css/CreateStudentProfile.css';
import { API_BASE_URL } from '../../../api';

const CreateStudentProfile = () => {
  const { student_usn } = useParams();
  const navigate = useNavigate();
  const [studentProfile, setStudentProfile] = useState({
    student_name: '',
    student_phoneno: '',
    student_program: '',
    student_batch: '',
    assigned_mentor: '',
    department: '',
    linkedin: '',
  });
  const [mentors, setMentors] = useState([]);
  const [filteredMentors, setFilteredMentors] = useState([]);
  const [uniqueDepartments, setUniqueDepartments] = useState([]);
  const [error, setError] = useState(null);

  const [startYear, setStartYear] = useState('');
  const [duration, setDuration] = useState('');

  useEffect(() => {
    fetch(`${API_BASE_URL}/mentors`)
      .then((response) => response.json())
      .then((data) => {
        setMentors(data);
        const departments = [...new Set(data.map((mentor) => mentor.mentor_department))];
        setUniqueDepartments(departments);
      })
      .catch((error) => setError(error.message));
  }, []);

  useEffect(() => {
    if (studentProfile.department) {
      setFilteredMentors(mentors.filter((mentor) => mentor.mentor_department === studentProfile.department));
    } else {
      setFilteredMentors([]);
    }
  }, [studentProfile.department, mentors]);

  const startYearOptions = Array.from({ length: 15 }, (_, i) => new Date().getFullYear() - 10 + i);
  const durationOptions = Array.from({ length: 6 }, (_, i) => i + 2);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudentProfile((prev) => ({ ...prev, [name]: value }));
  };

  const handleBatchChange = (e) => {
    const { name, value } = e.target;
    if (name === 'startYear') {
      setStartYear(value);
      if (duration) {
        setStudentProfile((prev) => ({
          ...prev,
          student_batch: `${value}-${parseInt(value) + parseInt(duration)}`,
        }));
      }
    } else if (name === 'duration') {
      setDuration(value);
      if (startYear) {
        setStudentProfile((prev) => ({
          ...prev,
          student_batch: `${startYear}-${parseInt(startYear) + parseInt(value)}`,
        }));
      }
    }
  };

  const handleLinkedinChange = (e) => {
    let inputValue = e.target.value.trim(); // Remove leading/trailing spaces
  
    // Remove any unnecessary tracking parameters if the user pastes a full LinkedIn URL
    inputValue = inputValue.split('?')[0]; // Removes everything after '?'
  
    // Extract the username if the user pasted a LinkedIn URL
    let username = inputValue.replace(/^(https?:\/\/)?(www\.)?linkedin\.com\/in\//, '');
  
    // Update state: Display username in input field, but store full LinkedIn URL
    setStudentProfile((prev) => ({
      ...prev,
      linkedin: `https://linkedin.com/in/${username}`, // Store complete LinkedIn URL
    }));
  };
  
  
  

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!studentProfile.student_batch) {
      setError('Please select a valid batch.');
      return;
    }

    const concatenatedProgram = `${studentProfile.student_program} in ${studentProfile.department}`;
    const profileData = { ...studentProfile, student_program: concatenatedProgram };

    fetch(`${API_BASE_URL}/student/profile/create/${student_usn}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profileData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.message) {
          alert(data.message);
          navigate(`/student/${student_usn}/profile`);
        }
      })
      .catch((error) => setError(error.message));
  };

  return (
    <div className="student-profile-form-container">
      <h2 className="student-profile-form-heading">Create Student Profile</h2>
      <h3 className="student-profile-form-heading1">Once the profile is submitted, it cannot be edited.</h3>
      {error && <p className="student-profile-form-error">{error}</p>}
      
      <form onSubmit={handleSubmit} className="student-profile-form">
        <div className="student-profile-form-group">
          <label>Name</label>
          <input type="text" name="student_name" value={studentProfile.student_name} onChange={handleChange} placeholder="Enter full name" />
        </div>

        <div className="student-profile-form-group">
          <label>Phone Number</label>
          <input type="text" name="student_phoneno" value={studentProfile.student_phoneno} onChange={handleChange} placeholder="Enter phone number" maxLength="10" />
        </div>

        <div className="student-profile-form-group">
          <label>Program</label>
          <select name="student_program" value={studentProfile.student_program} onChange={handleChange}>
            <option value="">Select Program</option>
            <option value="BSc.">Bachelors of Science</option>
            <option value="MSc.">Masters of Science</option>
          </select>
        </div>

        {studentProfile.student_program && (
          <div className="student-profile-form-group">
            <label>Department</label>
            <select name="department" value={studentProfile.department} onChange={handleChange}>
              <option value="">Select Department</option>
              {uniqueDepartments.map((dept, index) => (
                <option key={index} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
        )}

        <div className="student-profile-form-group">
          <label>Batch</label>
          <div className="batch-dropdowns">
            <select name="startYear" value={startYear} onChange={handleBatchChange}>
              <option value="">Start Year</option>
              {startYearOptions.map((year) => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
            <span> - </span>
            <select name="duration" value={duration} onChange={handleBatchChange}>
              <option value="">Duration (years)</option>
              {durationOptions.map((years) => (
                <option key={years} value={years}>{years} Years</option>
              ))}
            </select>
          </div>
          {studentProfile.student_batch && <p>Selected Batch: <strong>{studentProfile.student_batch}</strong></p>}
        </div>

        <div className="student-profile-form-group">
          <label>Assigned Mentor</label>
          <select name="assigned_mentor" value={studentProfile.assigned_mentor} onChange={handleChange}>
            <option value="">Select Mentor</option>
            {filteredMentors.map((mentor) => (
              <option key={mentor.mentor_id} value={mentor.mentor_id}>{mentor.mentor_name}</option>
            ))}
          </select>
        </div>

        <div className="student-profile-form-group">
  <label>LinkedIn</label>
  <input
    type="text"
    name="linkedin"
    value={studentProfile.linkedin.replace('https://linkedin.com/in/', '')} // Show only username
    onChange={handleLinkedinChange}
    placeholder="Enter LinkedIn username"
  />
</div>
        <button type="submit" className="student-profile-form-submit-btn">Create Profile</button><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
      </form>
    </div>
  );
};

export default CreateStudentProfile;
