import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../../api";
import '../../assets/css/Logout.css';

const Logout = () => {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(true);
  const [message, setMessage] = useState("Are you sure you want to log out?");

  const handleConfirmLogout = async () => {
    setMessage("Byeee! Logging out now...");

    const token = sessionStorage.getItem("access_token");
    const userId = sessionStorage.getItem("userId");

    if (!token || !userId) {
      navigate("/"); // Redirect home if not logged in
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/logout/${userId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        sessionStorage.clear();

        // Wait for the user to see "Byeee!" before redirecting
        setTimeout(() => {
          navigate("/login");
        }, 1500);
      } else {
        setMessage("Logout failed. Try again.");
      }
    } catch (err) {
      setMessage("An error occurred. Please try again.");
    }
  };

  return (
    showModal && (
      <div className="modal">
        <div className="modal-content">
          <p>{message}</p>
          {message === "Are you sure you want to log out?" && (
            <>
              <button onClick={handleConfirmLogout}>Yes</button>
              <button onClick={() => navigate(`/student/${sessionStorage.getItem("userId")}/profile`)}>No</button>
            </>
          )}
        </div>
      </div>
    )
  );
};

export default Logout;
