import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Link } from 'react-router-dom'; // Importing Link for navigation
import PullToRefresh from 'react-simple-pull-to-refresh';
import '../../assets/css/Login.css'; // Assuming you have a separate CSS file for login styling
import { API_BASE_URL } from '../../api';
// import Chatbot from '../Chatbot';

const Login = () => {
  const [loginData, setLoginData] = useState({ id: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const tokenExpiry = sessionStorage.getItem('tokenExpiry');
    const currentTime = Date.now();

    if (tokenExpiry && currentTime < tokenExpiry) {
      const role = sessionStorage.getItem('role');
      const userId = sessionStorage.getItem('userId');
      if (role && userId) {
        console.log("User already logged in. Redirecting...");
        navigate(`/${role}/${userId}`);
      }
    }
  }, [navigate]);

  const handleChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/login`, loginData);
      const { role, access_token, expires_in } = response.data;

      // Store data in sessionStorage
      sessionStorage.setItem('access_token', access_token);
      sessionStorage.setItem('role', role);
      sessionStorage.setItem('userId', loginData.id);
      const expirationTime = Date.now() + expires_in * 1000;
      sessionStorage.setItem('tokenExpiry', expirationTime);

      // Navigate based on role
      if (role === 'mentor') {
        navigate(`/mentor/${loginData.id}/profile`);
      } else if (role === 'student') {
        navigate(`/student/${loginData.id}/profile`);
      } else if (role === 'admin') {
        navigate(`/admin/${loginData.id}/profile`);
      } else {
        setError('Unknown role. Please contact support.');
        console.error("Unknown role:", role);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Invalid ID or password. Please try again.');
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  // Refresh Function
  const handleRefresh = async () => {
    await new Promise((resolve) => setTimeout(resolve, 1000)); // Simulate API call
    window.location.href = window.location.href; // Force full page refresh
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="login-container">
        <Link to="/">
          <div className="login-logo-left"></div>
        </Link>
        <div className="login-logo-right"></div> {/* Right logo */}
        <div className="login-left">
          <h2>Login</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input
                type="text"
                id="id"
                name="id"
                value={loginData.id}
                onChange={handleChange}
                placeholder="Username"
                maxLength={10}
                required
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                id="password"
                name="password"
                value={loginData.password}
                onChange={handleChange}
                placeholder="Password"
                required
              />
            </div>
            {error && <p className="error-message">{error}</p>}
            <button type="submit" className="login-button" disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </button>
            <button type="button" className="signup-button" onClick={() => navigate('/student_signup')}>Sign Up</button>
          </form>
          {/* Forgot Password Link */}
          <div className="forgot-password-container">
            <Link to="/forgotpassword" className="forgot-password-link">
              Change/Forgot Password?
            </Link>
          </div>
        </div>

        <div className="login-right">
          <h3>Mentee Tracker</h3>
          <p>
            Welcome to the Mentee Tracker, your personalized platform for tracking and managing <br/>your mentees’ progress. Monitor their activities, schedule meetings, <br/>and ensure their continuous growth. Stay connected and <br/>make the most of your mentorship journey.
          </p>
        </div>
        {/* <Chatbot /> */}
        {/* "Powered by Biogred" Text with Class */}
        <div className="login-powered-by">
          <p>Powered by <a href="https://linktr.ee/biogred" target="_blank" rel="noopener noreferrer" className="login-footer-link">BIOGRED</a></p>
        </div>
      </div>
    </PullToRefresh>
  );
};

export default Login;