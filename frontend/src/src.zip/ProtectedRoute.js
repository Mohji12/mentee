import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ element, userId }) => {
  const token = sessionStorage.getItem('access_token');
  const tokenExpiry = sessionStorage.getItem('tokenExpiry');
  const loggedInUserId = sessionStorage.getItem('userId'); // Get stored user ID

  // Extract the ID from the URL manually
  const pathSegments = window.location.pathname.split('/');
  const paramId = pathSegments[2]; // Extract user ID from URL (3rd part of path)

  // Check if token exists and is valid
  const isTokenValid = token && Date.now() < parseInt(tokenExpiry, 10);

  // Prevent unauthorized access
  if (!isTokenValid) {
    return <Navigate to="/login" replace />;
  }

  if (loggedInUserId !== paramId) {
    // Redirect and refresh the page
    window.location.replace(`/student/${loggedInUserId}`);
    return null; // Ensure nothing renders before redirect
  }

  return element;
};

export default PrivateRoute;
