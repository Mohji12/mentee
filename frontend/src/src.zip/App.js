import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import PrivateRoute from './ProtectedRoute';
import LandingPage from './pages/Landing';
import StudentSignup from './pages/auth/StudentSignup';
import Login from './pages/auth/Login';
import Logout from './pages/auth/Logout';
import ForgotPassword from './pages/auth/ForgotPassword';
import MentorDashboard from './pages/mentor/MentorDashboard';
import Profile from './pages/mentor/components/MentorProfile';
import AssignedStudents from './pages/mentor/components/AssignedStudents';
import ActivityTracking from './pages/mentor/components/ActivityTracking';
import MentorMeetings from './pages/mentor/components/Meetings';
import StudentDashboard from './pages/student/StudentDashboard';
import StudentProfile from './pages/student/components/StudentProfile';
import CreateStudentProfile from './pages/student/components/CreateStudentProfile';
import PsychometricForm from './pages/student/components/PsychometricForm';
import ReportPage from './pages/student/components/Report';
import ActivitiesPage from './pages/student/components/Activities';
import StudentLoggedActivities from './pages/student/components/StudentLoggedActivities';
import StudentMeetings from './pages/student/components/Meetings';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminProfile from './pages/admin/components/AdminProfile';
import AdminActivities from './pages/admin/components/AdminActivities';
import AdminStudents from './pages/admin/components/AdminStudents';
import LinkPage from './pages/Links';
import TermsOfService from './pages/components/TermsofService';
import PrivacyPolicy from './pages/components/PrivacyPolicy';

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/student_signup" element={<StudentSignup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/forgotpassword" element={<ForgotPassword />} />
        <Route path="/biogred" element={<LinkPage />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/terms-of-service" element={<TermsOfService />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />

        {/* Mentor Dashboard with Nested Routes */}
        <Route path="/mentor/:mentor_id" element={<PrivateRoute userId="mentor_id" element={<MentorDashboard />} />}>
          <Route path="profile" element={<Profile />} />
          <Route path="assigned_students" element={<AssignedStudents />} />
          <Route path="activity_tracking" element={<ActivityTracking />} />
          <Route path="meetings" element={<MentorMeetings />} />
        </Route>

        {/* Mentor Dashboard with Nested Routes */}
        <Route path="/admin/:admin_id" element={<PrivateRoute userId="admin_id" element={<AdminDashboard />} />}>
          <Route path="profile" element={<AdminProfile/>} /> 
          <Route path="allstudents" element={<AdminStudents />} />
          <Route path="activities" element={<AdminActivities />} />
        </Route>

        {/* Student Dashboard with Nested Routes */}
        <Route path="/student/:student_usn" element={<PrivateRoute userId="student_usn" element={<StudentDashboard />} />}>
          <Route path="profile" element={<StudentProfile />} />
          <Route path="createprofile" element={<CreateStudentProfile />} />
          <Route path="psychometric" element={<PsychometricForm />} />
          <Route path="report" element={<ReportPage />} />
          <Route path="activities" element={<ActivitiesPage />} />
          <Route path="logged_activities" element={<StudentLoggedActivities />} />
          <Route path="scheduled_meetings" element={<StudentMeetings />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;