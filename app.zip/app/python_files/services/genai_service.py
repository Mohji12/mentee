import google.generativeai as genai

# Configure the Gemini API (replace with your actual API key)
genai.configure(api_key="AIzaSyA2jix3V7SXAyVIcirjLKaz5joxL9Zn9fE")  # Replace with your actual API key
model = genai.GenerativeModel("gemini-2.5-flash")




