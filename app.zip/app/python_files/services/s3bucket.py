import boto3

# AWS S3 Configuration
AWS_ACCESS_KEY = "AKIA5WLTTM2KMV2R3UKC"
AWS_SECRET_KEY = "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"
S3_BUCKET_NAME = "jgi-mentee-activity-proofs-prod"
S3_REGION = "ap-south-1"
S3_EXPIRATION = 600  # 7 days in seconds

# Initialize S3 client
s3_client = boto3.client(
    "s3",
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
    region_name=S3_REGION
)
